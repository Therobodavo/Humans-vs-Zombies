﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour {
    public float radius;
	// Use this for initialization
	void Start ()
    {
	    radius = 1;	
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
