﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
 * Zombie Class
 * Code to move Zombie
 * Programmed by David Knolls
 */
public class Zombie : Vehicle {

    //Human that the zombie is chasing
    public GameObject zombieTarget;

    //Weight used
    public float seekWeight;

	// Use this for initialization
	public override void Start ()
    {
		base.Start();
	}

    //Calculates steering forces
    public override void CalcSteeringForces()
    {
        Vector3 ultimateForce = new Vector3(0, 0, 0);
        ultimateForce += Seek(zombieTarget.transform.position)  * seekWeight;
        ultimateForce += ObstacleAvoidance();
        ultimateForce = Vector3.ClampMagnitude(ultimateForce, maxSpeed);

        ApplyForce(ultimateForce);
    }
}
