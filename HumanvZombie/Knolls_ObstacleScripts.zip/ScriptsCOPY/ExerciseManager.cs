﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
 * Manager Class
 * Code to get collision and manage objects
 * Programmed by David Knolls
 */
public class ExerciseManager : MonoBehaviour
{
    //Prefabs used
    public GameObject human;
    public GameObject zombie;

    //Used for positioning
    public float screenWidth;

    //Lists to store humans and zombies
    List<GameObject> humans = new List<GameObject>();
    List<GameObject> zombies = new List<GameObject>();


    // Use this for initialization
    void Start ()
    {
        screenWidth = 9.5f;
        //Creates humans
		for(int i = 0; i < 10; i++)
        {
            humans.Add(createRandomHuman());
        }

        //Creates zombie
        zombie.transform.position = new Vector3(Random.Range(-screenWidth,screenWidth), .25f, Random.Range(-screenWidth,screenWidth));
        zombie.GetComponent<Zombie>().zombieTarget = humans[0];
        zombies.Add(Instantiate(zombie));

        //Updates the zombie's target/nearest human
        updateZombieTarget();
        
	}
	
	// Update is called once per frame
	void Update ()
    {
        //Updates Zombie's target
		updateZombieTarget();

        //Checks if humans should run away
        humanCheckForZombies();
	}

    //Creates a random human
    public GameObject createRandomHuman()
    {
        human.transform.position = new Vector3(Random.Range(-screenWidth,screenWidth), .25f, Random.Range(-screenWidth,screenWidth));
        return Instantiate(human);
    }

    //Updates the Zombie's target
    private void updateZombieTarget()
    {
        GameObject closest = humans[0];
        foreach(GameObject hum in humans)
        {
            if((hum.transform.position - zombies[0].transform.position).magnitude < (closest.transform.position - zombies[0].transform.position).magnitude)
            {
                closest = hum;
            }
        }
        zombies[0].GetComponent<Zombie>().zombieTarget = closest; 
    }

    //Humans check if they need to run away from a zombie
    private void humanCheckForZombies()
    {
        foreach(GameObject hum in humans)
        {
            if((hum.transform.position - zombies[0].transform.position).magnitude < 6f)
            {
                hum.GetComponent<Human>().zombieChaser = zombies[0];
                hum.GetComponent<Human>().fleeing = true;
            }
            else
            {
                hum.GetComponent<Human>().fleeing = false;
            }
        }
    }
}
