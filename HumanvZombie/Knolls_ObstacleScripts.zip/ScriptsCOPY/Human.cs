﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
 * Human Class
 * Code to move Human
 * Programmed by David Knolls
 */
public class Human : Vehicle {

    //Prefabs used
    public GameObject humanTarget;
    public GameObject zombieChaser;

    //Weights used
    public float seekWeight;
    public float fleeWeight;

    //Is human fleeing from zombie?
    public bool fleeing;

	// Use this for initialization
	public override void Start () 
    {
        fleeing = false;
		base.Start();
	}

    //Calculates steering forces
    public override void CalcSteeringForces()
    {
        Vector3 ultimateForce = new Vector3(0, 0, 0);

       // ultimateForce += Seek(humanTarget.transform.position) * seekWeight;

        //if zombie is too close
        if(fleeing)
        {
            ultimateForce += Flee(zombieChaser.transform.position) * fleeWeight;
        }
        ultimateForce += ObstacleAvoidance();

        ultimateForce.y = 0;

        ultimateForce = Vector3.ClampMagnitude(ultimateForce, maxSpeed);

        ApplyForce(ultimateForce);
    }
}
