﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
 * Vehicle Class
 * Moves the attached object and can flee/seek
 * Programmed by David Knolls
 */
public abstract class Vehicle : MonoBehaviour 
{

	// Vectors for force-based movement
	public Vector3 acceleration;
	public Vector3 direction;
	public Vector3 velocity;
	public Vector3 vehiclePosition;

	// Floats for force-based movement
	public float mass;
    public float maxSpeed;
    public float maxForce;
    public float radius;

    public Vector3 desiredForward;

	// Use this for initialization
    public virtual void Start () 
	{
        desiredForward = transform.forward;
	}
	
	// Update is called once per frame
	void Update ()
	{
        CalcSteeringForces();
        UpdatePosition();
        SetTransform();
	}

	// void ApplyForce()
	// Applies a force to this vehicle's acceleration
	// Mass affects acceleration
	public void ApplyForce(Vector3 force)
	{
		acceleration += force / mass;
	}


    //Updates Position of vehicle
    public void UpdatePosition()
    {
        vehiclePosition = transform.position;

		// 1. Add accel to velocity
		velocity += acceleration * Time.deltaTime;

        //Clamps velocity
        velocity = Vector3.ClampMagnitude(velocity,maxSpeed);

		// 2. Add vel to pos
		vehiclePosition += velocity * Time.deltaTime;

		// 3. Get a normalized velocity as direction
		direction = velocity.normalized;

		// 4. Refresh accel
		acceleration = Vector3.zero;

        transform.position = vehiclePosition;
    }

    //Sets transform of vehicle (forward)
    public void SetTransform()
    {

        if(desiredForward.x < direction.x)
        {
            desiredForward.x+= 0.02f;
        }
        else if(desiredForward.x > direction.x)
        {
            desiredForward.x-= 0.02f;
        }
        if (desiredForward.z < direction.z)
        {
            desiredForward.z+= 0.02f;
        }
        else if(desiredForward.z > direction.z)
        {
           desiredForward.z-= 0.02f;
        }

        transform.forward = desiredForward;
    }

    //Seek towards a target
    public Vector3 Seek(Vector3 target)
    {
        //Get desired velocity
        Vector3 desVel = target - vehiclePosition;

        //Normalize
        desVel.Normalize();

        //Set to max speed
        desVel *= maxSpeed;

        //Calculate steering force
        Vector3 steeringForce = desVel - velocity;
        return steeringForce;

    }

    public Vector3 Flee(Vector3 target)
    {
        //Get desired velocity
        Vector3 desVel = (vehiclePosition - target);

        //Normalize
        desVel.Normalize();

        //Set to max speed
        desVel *= maxSpeed;

        //Calculate steering force
        Vector3 steeringForce = desVel - velocity;
        return steeringForce;
    }

    //Avoids Obstacles
    public Vector3 ObstacleAvoidance() 
    {
        Vector3 steeringForce = Vector3.zero;
        Vector3 desVel;
        GameObject closest = GameObject.FindGameObjectWithTag("Tree");
        foreach(GameObject i in GameObject.FindGameObjectsWithTag("Tree")) 
        {
            if((vehiclePosition - i.transform.position).magnitude < (vehiclePosition - closest.transform.position).magnitude && Vector3.Dot(vehiclePosition - closest.transform.position,gameObject.transform.right) > 0)
            {
                closest = i;
            }
        }

        if(closest == GameObject.FindGameObjectWithTag("Tree") && Vector3.Dot(vehiclePosition - closest.transform.position,gameObject.transform.right) <= 0)
        {
            return Vector3.zero;
        }
        if(radius + closest.GetComponent<Obstacle>().radius < Vector3.Dot(vehiclePosition - closest.transform.position,gameObject.transform.right))
        {
            if(Vector3.Dot(gameObject.transform.right, vehiclePosition - closest.transform.position) < 0)
            {
                //right hand
                desVel = -gameObject.transform.right;
            }
            else 
            {
                //left hand
                desVel = gameObject.transform.right;
            }
            desVel.Normalize();
            desVel *= maxSpeed;
            steeringForce = desVel - velocity;
            Debug.Log("Force: + " + steeringForce.magnitude);
        }

        return steeringForce;
    }
    public abstract void CalcSteeringForces();
}
