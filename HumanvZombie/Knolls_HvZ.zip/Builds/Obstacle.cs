﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
 * Obstacle Class
 * Code to get info for Obstacles
 * Programmed by David Knolls
 */
public class Obstacle : MonoBehaviour {
    public float radius;
	// Use this for initialization
	void Start ()
    {
        //radius used for obstacles set
	    radius = .5f;	
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
